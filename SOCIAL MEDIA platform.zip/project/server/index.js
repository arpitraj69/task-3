import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import initSqlJs from 'sql.js';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import { webcrypto } from 'crypto';

dotenv.config();

const app = express();
const __dirname = dirname(fileURLToPath(import.meta.url));
const crypto = webcrypto;

let db;

// Initialize SQL.js
async function initDB() {
  const SQL = await initSqlJs();
  db = new SQL.Database();
  
  // Database initialization
  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      role TEXT NOT NULL,
      department TEXT,
      year TEXT,
      avatar TEXT
    );

    CREATE TABLE IF NOT EXISTS posts (
      id TEXT PRIMARY KEY,
      content TEXT NOT NULL,
      image TEXT,
      author_id TEXT NOT NULL,
      timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (author_id) REFERENCES users (id)
    );

    CREATE TABLE IF NOT EXISTS comments (
      id TEXT PRIMARY KEY,
      content TEXT NOT NULL,
      post_id TEXT NOT NULL,
      author_id TEXT NOT NULL,
      timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (post_id) REFERENCES posts (id),
      FOREIGN KEY (author_id) REFERENCES users (id)
    );

    CREATE TABLE IF NOT EXISTS likes (
      post_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      PRIMARY KEY (post_id, user_id),
      FOREIGN KEY (post_id) REFERENCES posts (id),
      FOREIGN KEY (user_id) REFERENCES users (id)
    );
  `);

  // Add a test user if none exists
  const testUser = {
    id: 'test-user-1',
    name: 'Dr. Sarah Johnson',
    email: 'test@example.com',
    password: await bcrypt.hash('password123', 10),
    role: 'teacher',
    department: 'Computer Science',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330',
  };

  db.run(`
    INSERT OR IGNORE INTO users (id, name, email, password, role, department, avatar)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `, [testUser.id, testUser.name, testUser.email, testUser.password, testUser.role, testUser.department, testUser.avatar]);

  // Add default posts
  const defaultPosts = [
    {
      id: crypto.randomUUID(),
      content: "Exciting news! Our department is organizing a hackathon next month. The theme is 'Sustainable Technology Solutions.' Open to all students. Stay tuned for registration details! 🚀 #CampusHackathon #Innovation",
      author_id: testUser.id,
      image: 'https://images.unsplash.com/photo-1515378960530-7c0da6231fb1',
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(), // 2 hours ago
    },
    {
      id: crypto.randomUUID(),
      content: "Just published our research paper on 'Advanced Machine Learning Algorithms in Education.' Proud of our team's hard work! Check it out in the department's research portal. 📚 #Research #AI #Education",
      author_id: testUser.id,
      timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(), // 24 hours ago
    }
  ];

  defaultPosts.forEach(post => {
    db.run(`
      INSERT OR IGNORE INTO posts (id, content, image, author_id, timestamp)
      VALUES (?, ?, ?, ?, ?)
    `, [post.id, post.content, post.image, post.author_id, post.timestamp]);
  });
}

app.use(cors());
app.use(express.json());

// Authentication middleware
const auth = (req, res, next) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) throw new Error('No token provided');
    
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'default-secret-key');
    req.user = decoded;
    next();
  } catch (error) {
    res.status(401).json({ error: 'Authentication failed' });
  }
};

// Auth routes
app.post('/auth/register', async (req, res) => {
  try {
    const { name, email, password, role } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    const id = crypto.randomUUID();

    db.run(`
      INSERT INTO users (id, name, email, password, role)
      VALUES (?, ?, ?, ?, ?)
    `, [id, name, email, hashedPassword, role]);

    res.status(201).json({ message: 'User created successfully' });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

app.post('/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const stmt = db.prepare('SELECT * FROM users WHERE email = ?');
    const result = stmt.get([email]);
    stmt.free();

    if (!result || !await bcrypt.compare(password, result.password)) {
      throw new Error('Invalid credentials');
    }

    const token = jwt.sign({ id: result.id }, process.env.JWT_SECRET || 'default-secret-key');
    const { password: _, ...userData } = result;
    
    res.json({ token, user: userData });
  } catch (error) {
    res.status(401).json({ error: error.message });
  }
});

// Posts routes
app.get('/posts', auth, (req, res) => {
  const stmt = db.prepare(`
    SELECT 
      p.*,
      u.name as author_name,
      u.role as author_role,
      u.avatar as author_avatar,
      u.department as author_department,
      COUNT(DISTINCT l.user_id) as likes_count
    FROM posts p
    JOIN users u ON p.author_id = u.id
    LEFT JOIN likes l ON p.id = l.post_id
    GROUP BY p.id
    ORDER BY p.timestamp DESC
  `);
  const posts = stmt.all();
  stmt.free();

  res.json(posts);
});

app.post('/posts', auth, (req, res) => {
  try {
    const { content, image } = req.body;
    const id = crypto.randomUUID();

    db.run(`
      INSERT INTO posts (id, content, image, author_id)
      VALUES (?, ?, ?, ?)
    `, [id, content, image, req.user.id]);

    res.status(201).json({ message: 'Post created successfully' });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

app.post('/posts/:id/like', auth, (req, res) => {
  const { id } = req.params;
  
  try {
    db.run(`
      INSERT INTO likes (post_id, user_id)
      VALUES (?, ?)
    `, [id, req.user.id]);
    
    res.json({ message: 'Post liked successfully' });
  } catch (error) {
    if (error.message.includes('UNIQUE constraint failed')) {
      db.run('DELETE FROM likes WHERE post_id = ? AND user_id = ?', [id, req.user.id]);
      res.json({ message: 'Post unliked successfully' });
    } else {
      res.status(400).json({ error: error.message });
    }
  }
});

app.post('/posts/:id/comments', auth, (req, res) => {
  try {
    const { id } = req.params;
    const { content } = req.body;
    const commentId = crypto.randomUUID();

    db.run(`
      INSERT INTO comments (id, content, post_id, author_id)
      VALUES (?, ?, ?, ?)
    `, [commentId, content, id, req.user.id]);

    res.status(201).json({ message: 'Comment added successfully' });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Initialize database and start server
initDB().then(() => {
  const PORT = process.env.PORT || 3000;
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
}).catch(console.error);