import axios from 'axios';
import { useAuthStore } from '../store/authStore';

const API_URL = 'http://localhost:3000';

const client = axios.create({
  baseURL: API_URL,
});

client.interceptors.request.use((config) => {
  const token = useAuthStore.getState().token;
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const api = {
  auth: {
    login: (credentials: { email: string; password: string }) =>
      client.post('/auth/login', credentials),
    register: (userData: { name: string; email: string; password: string; role: string }) =>
      client.post('/auth/register', userData),
  },
  posts: {
    getAll: () => client.get('/posts'),
    create: (data: { content: string; image?: string }) => client.post('/posts', data),
    like: (id: string) => client.post(`/posts/${id}/like`),
    comment: (id: string, content: string) => 
      client.post(`/posts/${id}/comments`, { content }),
  },
};