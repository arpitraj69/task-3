export interface User {
  id: string;
  name: string;
  role: 'student' | 'teacher';
  avatar: string;
  department: string;
  year?: string;
}

export interface Post {
  id: string;
  author: User;
  content: string;
  timestamp: Date;
  likes: number;
  comments: Comment[];
  image?: string;
}

export interface Comment {
  id: string;
  author: User;
  content: string;
  timestamp: Date;
}