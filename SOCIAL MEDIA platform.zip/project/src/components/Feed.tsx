import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { api } from '../api/client';
import CreatePost from './CreatePost';
import Post from './Post';
import type { Post as PostType } from '../types';

export default function Feed() {
  const { data: posts, isLoading, error } = useQuery({
    queryKey: ['posts'],
    queryFn: async () => {
      const response = await api.posts.getAll();
      return response.data.map((post: any) => ({
        id: post.id,
        content: post.content,
        image: post.image,
        timestamp: new Date(post.timestamp),
        likes: post.likes_count,
        author: {
          id: post.author_id,
          name: post.author_name,
          role: post.author_role,
          avatar: post.author_avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(post.author_name)}`,
        },
        comments: [], // We'll implement comments fetching separately
      }));
    },
  });

  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 text-red-600 p-4 rounded-lg">
        Failed to load posts. Please try again later.
      </div>
    );
  }

  return (
    <div>
      <CreatePost />
      {posts?.map((post: PostType) => (
        <Post key={post.id} post={post} />
      ))}
    </div>
  );
}