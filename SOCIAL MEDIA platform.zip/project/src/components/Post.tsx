import React, { useState } from 'react';
import { Heart, MessageCircle, Share2 } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import type { Post as PostType } from '../types';
import { api } from '../api/client';
import { useQueryClient } from '@tanstack/react-query';

interface PostProps {
  post: PostType;
}

export default function Post({ post }: PostProps) {
  const [isLiking, setIsLiking] = useState(false);
  const queryClient = useQueryClient();

  const handleLike = async () => {
    if (isLiking) return;

    try {
      setIsLiking(true);
      await api.posts.like(post.id);
      queryClient.invalidateQueries({ queryKey: ['posts'] });
    } catch (error) {
      console.error('Failed to like post:', error);
    } finally {
      setIsLiking(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow mb-6">
      <div className="p-4">
        <div className="flex items-center space-x-3">
          <img
            src={post.author.avatar}
            alt={post.author.name}
            className="w-10 h-10 rounded-full"
          />
          <div>
            <h3 className="font-semibold text-gray-900">{post.author.name}</h3>
            <div className="flex items-center space-x-2 text-sm text-gray-500">
              <span>{post.author.role}</span>
              <span>•</span>
              <span>{formatDistanceToNow(post.timestamp)} ago</span>
            </div>
          </div>
        </div>
        
        <p className="mt-3 text-gray-800">{post.content}</p>
        
        {post.image && (
          <img
            src={post.image}
            alt="Post content"
            className="mt-3 rounded-lg w-full object-cover max-h-96"
          />
        )}
        
        <div className="mt-4 flex items-center justify-between border-t border-gray-100 pt-4">
          <button 
            className={`flex items-center space-x-2 text-gray-600 hover:text-blue-500 ${
              isLiking ? 'opacity-50 cursor-not-allowed' : ''
            }`}
            onClick={handleLike}
            disabled={isLiking}
          >
            <Heart className="h-5 w-5" />
            <span>{post.likes}</span>
          </button>
          <button className="flex items-center space-x-2 text-gray-600 hover:text-blue-500">
            <MessageCircle className="h-5 w-5" />
            <span>{post.comments.length}</span>
          </button>
          <button className="flex items-center space-x-2 text-gray-600 hover:text-blue-500">
            <Share2 className="h-5 w-5" />
            <span>Share</span>
          </button>
        </div>
      </div>
      
      {post.comments.length > 0 && (
        <div className="bg-gray-50 p-4 rounded-b-lg">
          {post.comments.map((comment) => (
            <div key={comment.id} className="flex items-start space-x-3 mb-3 last:mb-0">
              <img
                src={comment.author.avatar}
                alt={comment.author.name}
                className="w-8 h-8 rounded-full"
              />
              <div className="flex-1">
                <div className="bg-white p-3 rounded-lg">
                  <h4 className="font-semibold text-sm">{comment.author.name}</h4>
                  <p className="text-gray-800 text-sm">{comment.content}</p>
                </div>
                <div className="mt-1 text-xs text-gray-500">
                  {formatDistanceToNow(comment.timestamp)} ago
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}