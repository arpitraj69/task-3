import React from 'react';
import { BookOpen, Users, Calendar, BookMarked, Settings } from 'lucide-react';
import { useAuthStore } from '../store/authStore';

export default function Sidebar() {
  const user = useAuthStore((state) => state.user);
  const menuItems = [
    { icon: BookOpen, label: 'Feed', active: true },
    { icon: Users, label: 'Groups' },
    { icon: Calendar, label: 'Events' },
    { icon: BookMarked, label: 'Courses' },
    { icon: Settings, label: 'Settings' },
  ];

  return (
    <div className="hidden lg:block w-64 fixed h-screen bg-white border-r border-gray-200 pt-20">
      <nav className="mt-4">
        {menuItems.map((item) => (
          <button
            key={item.label}
            className={`w-full flex items-center space-x-3 px-6 py-3 text-gray-700 hover:bg-gray-50 ${
              item.active ? 'text-blue-600 bg-blue-50' : ''
            }`}
          >
            <item.icon className="h-5 w-5" />
            <span className="font-medium">{item.label}</span>
          </button>
        ))}
      </nav>
      
      {user && (
        <div className="absolute bottom-0 w-full p-4 border-t border-gray-200">
          <div className="flex items-center space-x-3">
            <img
              src={user.avatar || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e"}
              alt={user.name}
              className="w-10 h-10 rounded-full"
            />
            <div>
              <h4 className="font-medium text-gray-900">{user.name}</h4>
              <p className="text-sm text-gray-500">{user.department}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}