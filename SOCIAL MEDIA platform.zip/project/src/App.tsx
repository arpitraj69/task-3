import React from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import Navbar from './components/Navbar';
import Sidebar from './components/Sidebar';
import Feed from './components/Feed';
import MobileNav from './components/MobileNav';

const queryClient = new QueryClient();

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <div className="min-h-screen bg-gray-100">
        <Navbar />
        <Sidebar />
        <MobileNav />
        
        <main className="lg:ml-64 pt-16">
          <div className="max-w-2xl mx-auto py-8 px-4">
            <Feed />
          </div>
        </main>
      </div>
    </QueryClientProvider>
  );
}

export default App;